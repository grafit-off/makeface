@include('_dynamicAdapt.js');
@include('_inert.js');
@include('_cookie.js');
@include('_modal.js');

// Burger
const navBurger = document.querySelector('.nav__burger');
const navMenu = document.querySelector('.nav__menu');
const navCart = document.querySelector('.nav__cart-btn');
const menuClose = document.querySelector('.menu__close-field')
const mediaQuery = window.matchMedia('(max-width: 991px)')

function burgerToggle() {
	navBurger.classList.toggle('active');
	setTimeout(() => {
		navMenu.classList.toggle('active');
	}, 10)
	navCart.classList.toggle('active');
	if (!mediaQuery.matches) {
		body.classList.remove('lock')
	}
	if (mediaQuery.matches) {
		body.classList.toggle('lock')
	}
}

navBurger.addEventListener('click', () => {
	burgerToggle()
})
menuClose.addEventListener('click', () => {
	burgerToggle()
})

// Inert burger
@include('_modal.js');
@include('_inert.js');

// Burger Menu
const wrapper = document.querySelector('.wrapper')
const headerBurger = document.querySelector('.header__burger');
const headerMenu = document.querySelector('.header__menu');
const md2 = window.matchMedia("(max-width: 767px)");

function burgerToggle() {
	headerBurger.classList.toggle('active');
	headerMenu.classList.toggle('active');
	body.classList.toggle('lock');
	headerMenu.inert = false;
	Array.from(wrapper.children).forEach((child) => {
		if (child !== document.querySelector('.header')) {
			child.inert = true;
		}
	});
	if (!headerMenu.classList.contains('active')) {
		headerMenu.inert = true;
		Array.from(wrapper.children).forEach((child) => {
			if (child !== document.querySelector('.header')) {
				child.inert = false;
			}
		});
	}
}
if (md2.matches) {
	headerMenu.inert = true;
	headerBurger.addEventListener('click', () => {
		burgerToggle()
	})
}
// -- //

// Inert
const menu = document.querySelector('.menu');
const burger = document.querySelector('.burger');
const close = document.querySelector('.close');
const body = document.body;

burger.addEventListener('click', showMenu);
close.addEventListener('click', hideMenu);

let keys = {
	ESC: 27,
};

menu.inert = true;

let previousActiveElement;

function showMenu() {
	menu.classList.add('menu-active');
	previousActiveElement = document.activeElement;

	Array.from(body.children).forEach((child) => {
		if (child !== menu) {
			child.inert = true;
		}
	});

	menu.inert = false;

	setTimeout(() => {
		close.focus();
	}, 100);

	document.addEventListener('keydown', (e) => {
		console.log(e.keyCode);

		if (e.keyCode == keys.ESC) {
			hideMenu();
		}
	});
}

function hideMenu() {
	menu.classList.remove('menu-active');

	Array.from(body.children).forEach((child) => {
		if (child !== menu) {
			child.inert = false;
		}
	});

	menu.inert = true;

	setTimeout(() => {
		previousActiveElement.focus();
	}, 100);
}
// -- //
// -- //
// Scroll to link
const isiPhone = (navigator.userAgent.match(/iPhone/i) != null);
const isiPad = (navigator.userAgent.match(/iPad/i) != null);
const isiPod = (navigator.userAgent.match(/iPod/i) != null);

if (isiPhone || isiPad || isiPod) {
	let linkNav = document.querySelectorAll('[href^="#"]'), //выбираем все ссылки к якорю на странице
		V = 0.2;  // скорость, может иметь дробное значение через точку (чем меньше значение - тем больше скорость)
	for (let i = 0; i < linkNav.length; i++) {
		linkNav[i].addEventListener('click', function (e) { //по клику на ссылку
			e.preventDefault(); //отменяем стандартное поведение
			let w = window.pageYOffset,  // производим прокрутка прокрутка
				hash = this.href.replace(/[^#]*(.*)/, '$1');  // к id элемента, к которому нужно перейти
			t = document.querySelector(hash).getBoundingClientRect().top,  // отступ от окна браузера до id
				start = null;
			requestAnimationFrame(step);  // подробнее про функцию анимации [developer.mozilla.org]
			function step(time) {
				if (start === null) start = time;
				let progress = time - start,
					r = (t < 0 ? Math.max(w - progress / V, w + t) : Math.min(w + progress / V, w + t));
				window.scrollTo(0, r);
				if (r != w + t) {
					requestAnimationFrame(step)
				} else {
					location.hash = hash  // URL с хэшем
				}
			}
		}, false);
	}
}
// -- //

// Active navigation on scroll
const nav = document.querySelector(".nav");
const menuWrapper = document.querySelector('.menu__wrapper')
const cartWrapper = document.querySelector('.cart__wrapper')
let prevScrollpos = window.pageYOffset;

function navOpen() {
	if (prevScrollpos != 0) {
		nav.classList.add('nav--active');
		menuWrapper.classList.add('menu__wrapper--onscroll')
		cartWrapper.classList.add('cart__wrapper--onscroll')

	} else {
		nav.classList.remove('nav--active');
		menuWrapper.classList.remove('menu__wrapper--onscroll');
		cartWrapper.classList.remove('cart__wrapper--onscroll')
	}
}
function navScroll() {
	window.onscroll = function () {
		let currentScrollPos = window.pageYOffset;
		if (prevScrollpos < currentScrollPos) {
			nav.classList.add('nav--active');
			menuWrapper.classList.add('menu__wrapper--onscroll')
			cartWrapper.classList.add('cart__wrapper--onscroll')
		} else if (prevScrollpos = currentScrollPos) {
			nav.classList.add('nav--active');
			menuWrapper.classList.add('menu__wrapper--onscroll')
			cartWrapper.classList.add('cart__wrapper--onscroll')
		} else {
			nav.classList.remove('nav--active');
			menuWrapper.classList.remove('menu__wrapper--onscroll');
			cartWrapper.classList.remove('cart__wrapper--onscroll')
		}
		prevScrollpos = currentScrollPos;
	}
}
navOpen()
navScroll()
// -- //

// Accordion
document.querySelectorAll('.acordion-triger').forEach((item) =>
	item.addEventListener('click', () => {
		item.parentNode.classList.toggle('acordion--active');
	})
)
// -- //

// Snackbar
const snackbarBtn = document.querySelector('.snackbar__btn');
const snackbar = document.querySelector(".snackbar");
function snackbarShow(text, type, time) {
	snackbar.innerHTML = `${text}`;
	snackbarBtn.disabled = true;
	if (time == null) {
		time = 3000;
	}
	if (type == 0) {
		snackbar.classList.add('show-notification');
		setTimeout(function () {
			snackbar.className = snackbar.className.replace("show-notification", "");
		}, time);
	} else if (type == 1) {
		snackbar.classList.add('show-attention');
		setTimeout(function () {
			snackbar.className = snackbar.className.replace("show-attention", "");
		}, time);
	}
	setTimeout(() => {
		snackbarBtn.disabled = false;
	}, time)
}
let condition = 1;
snackbarBtn.addEventListener('click', () => {
	if (condition == 1) {
		snackbarShow('Воу, воу... Проблема? Тут 1', 1)
		condition++
	} else if (condition == 2) {
		snackbarShow('Даже так? Тут 2', 0, 3000)
		condition++
	} else if (condition == 3) {
		snackbarShow('Даже так? Тут 3', 0, 3000)
		condition++
	} else if (condition == 4) {
		snackbarShow('Даже так? Тут 4', 1, 3000)
		condition++
	}
})
// -- //
// cookies
const cookieEl = document.querySelector('.cookie-block');
const okEl = document.querySelector('.ok');

okEl.addEventListener('click', () => {
	cookieEl.style.display = 'none';
});

let cookies = () => {
	if (!Cookies.get('hide-cookie')) {
		setTimeout(() => {
			cookieEl.style.display = 'block';
		}, 1000);
	}

	Cookies.set('hide-cookie', 'true', {
		expires: 30
	});
}
cookies();
// -- //

// active class of menu items onscroll
window.addEventListener('scroll', () => {
	let scrollDistance = window.scrollY;

	if (window.innerWidth > 768) {
		document.querySelectorAll('.section').forEach((el, i) => {
			if (el.offsetTop - document.querySelector('.nav').clientHeight <= scrollDistance) {
				document.querySelectorAll('.nav a').forEach((el) => {
					if (el.classList.contains('active')) {
						el.classList.remove('active');
					}
				});

				document.querySelectorAll('.nav li')[i].querySelector('a').classList.add('active');
			}
		});
	}
});